# Ansible role: ceph-mds

Documentation is available at http://docs.ceph.com/ceph-ansible/.
